﻿namespace A4EPARC.Enums
{
    public enum SiteTextCode
    {
        Undefined = 0,
        PreContemplation = 1,
        UnreflectiveAction = 2,
        Contemplation = 3,
        Preparation = 4,
        Action = 5,
        AimStatement = 6
    }
}