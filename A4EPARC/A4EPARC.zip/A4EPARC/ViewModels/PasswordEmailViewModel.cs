﻿namespace A4EPARC.ViewModels
{
    public class PasswordEmailViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}