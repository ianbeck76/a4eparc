﻿namespace A4EPARC.ViewModels
{
    public class CompanySchemeViewModel
    {
        public int SchemeId { get; set; }

        public int CompanyId { get; set; }

        public string SchemeName { get; set; }
    }
}