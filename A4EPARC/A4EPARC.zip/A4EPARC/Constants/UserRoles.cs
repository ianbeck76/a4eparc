﻿namespace A4EPARC.Constants
{
    public struct UserRoles
    {
        public const string IsSuperAdmin = "IsSuperAdmin";
        public const string IsAdmin = "IsAdmin";
        public const string IsViewer = "IsViewer";
    }
}